# Spacetime Framework (Python)
===========
Python version required: Python 2.7

Required packages to be installed:

1. flask
2. flask_restful
3. requests
4. pcc (Wheel file included. Install using pip: ``pip install lib/pcc-x.y.z-py2-none-any.whl``)

Additionally, some of the example applications require pygame.


