class Modes(object):
    Producing = "producing"
    Tracker = "tracking"
    Getter = "getting"
    GetterSetter = "gettingsetting"
    Setter = "setting"
    Deleter = "deleting"
    Taker = "taking"
    TakerSetter = "takingsetting"