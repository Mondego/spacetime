from uuid import uuid4
from spacetime.managers.version_graph import Graph
import spacetime.utils.utils as utils
from spacetime.utils.enums import Event


class FullStateVersionManager(object):
    def __init__(self, appname, types):
        self.types = types
        self.type_map = {tp.__r_meta__.name: tp for tp in types}
        self.version_graph = Graph()
        self.state_to_app = dict()
        self.app_to_state = dict()
        self.logger = utils.get_logger("%s_FullStateVersionManager" % appname)

    def set_app_marker(self, appname, end_v):
        self.state_to_app.setdefault(end_v, set()).add(appname)

    def receive_data(self, appname, versions, package):
        start_v, end_v = versions
        if start_v == end_v:
            # The versions are the same, lets ignore.
            return True
        if start_v != self.version_graph.head.current:
            self.resolve_conflict(start_v, end_v, package)
        else:
            self.version_graph.continue_chain(start_v, end_v, package)
        self.maintain(appname, end_v)
        return True

    def retrieve_data(self, appname, version):
        data, version_change = self.retrieve_data_nomaintain(version)
        self.set_app_marker(appname, version_change[1])
        return data, version_change

    def retrieve_data_nomaintain(self, version):
        merged = dict()
        for delta in self.version_graph[version:]:
            merged = utils.merge_state_delta(merged, delta)
        return merged, [version, self.version_graph.head.current]

    def data_sent_confirmed(self, app, version):
        self.maintain(app, version)

    def resolve_conflict(self, start_v, end_v, package):
        new_v = self.version_graph.head.current
        change, _ = self.retrieve_data_nomaintain(start_v)
        t_new_merge, t_conflict_merge = self.operational_transform(
            start_v, change, package)
        merge_v = str(uuid4())
        self.version_graph.continue_chain(new_v, merge_v, t_new_merge)
        self.version_graph.continue_chain(end_v, merge_v, t_conflict_merge)

    def operational_transform(self, start, new_path, conflict_path):
        # This will contain all changes in the merge that do not conflict with
        # new changes in place + merged resolutions.
        t_new_merge = dict()
        # This will contain all merged resolutions. + changes in place not with 
        # this version change.
        t_conflict_merge = dict()
        for tpname in new_path:
            if tpname in conflict_path:
                # Merge tp changes.
                tp_merge, tp_conf_merge = self.ot_on_type(
                    tpname, start, new_path[tpname], conflict_path[tpname])
                t_new_merge[tpname] = tp_merge
                t_conflict_merge[tpname] = tp_conf_merge
            else:
                # tp only in new, not in conflict.
                # Can add this to changes that divergent path would need.
                t_conflict_merge[tpname] = new_path[tpname]
        for tpname in conflict_path:
            if tpname not in new_path:
                # tp only in conflict, not in master branch.
                # Can add this to changes that master branch would need.
                t_new_merge[tpname] = conflict_path[tpname]
        return t_new_merge, t_conflict_merge

    def ot_on_type(self, dtpname, start, new_tp_change, conflict_tp_change):
        tp_merge = dict()
        tp_conf_merge = dict()
        for oid in new_tp_change:
            if oid in conflict_tp_change:
                # Merge oid change.
                obj_merge, obj_conf_merge = self.ot_on_obj(
                    dtpname, oid,
                    start, new_tp_change[oid], conflict_tp_change[oid])
                tp_merge[oid] = obj_merge
                tp_conf_merge[oid] = obj_conf_merge
            else:
                # obj only in master path.
                tp_conf_merge[oid] = new_tp_change[oid]
        for oid in conflict_tp_change:
            if oid not in new_tp_change:
                # oid only in conflict, not in master.
                # Add it to master.
                tp_merge[oid] = conflict_tp_change[oid]
        return tp_merge, tp_conf_merge

    def ot_on_obj(self, dtpname, oid, start, new_obj_change, conf_obj_change):
        dtype = self.type_map[dtpname]
        obj_merge = dict()
        obj_conf_merge = dict()

        # dtpname event determines the base type's changes.
        event_new = new_obj_change["types"][dtpname]
        event_conf = conf_obj_change["types"][dtpname]
        if event_new is Event.New and event_conf is Event.New:
            # Both paths have created a new object.
            # Resolve that.
            if dtype.__r_meta__.merge is not None:
                obj_merge, obj_conf_merge = self.resolve_with_custom_merge(
                    dtype, oid,
                    None,  # original
                    self.make_temp_obj(
                        start, dtype, oid, with_change=new_obj_change),  # new
                    self.make_temp_obj(
                        start, dtype, oid,
                         with_change=conf_obj_change),  # conflicting
                    new_obj_change, conf_obj_change)
            else:
                # Choose the New as other apps might have started work
                # on this object.
                obj_merge = dict()
                obj_conf_merge = self.dim_diff(conf_obj_change, new_obj_change)
        elif event_new is Event.New and event_conf is Event.Modification:
            # This has to be an error. How did an object get modified if
            # the object was not there at start.
            raise RuntimeError(
                "Divergent modification received when object was"
                " created in the main line.")
        elif event_new is Event.New and event_conf is Event.Delete:
            # This has to be an error. How did an object get deleted if
            # the object was not there at start.
            raise RuntimeError(
                "Divergent deletion received when "
                "object was created in the main line.")
        elif event_new is Event.Modification and event_conf is Event.New:
            # resolving between an modified object and
            #  an object that was sent as a new record.
            # Should be error again as this would not be possible.
            # If the object was modified from the branch line, 
            # then it existed in the branch.
            # If the object existed, then the diverging app should 
            # have had the obj too as it
            # forked from that point. So the object cannot be returned as new.
            raise RuntimeError(
                "Divergent deletion received when"
                " object was created in the main line.")
        elif (event_new is Event.Modification
                  and event_conf is Event.Modification):
            # resolve between two different modifications.
            if dtype.__r_meta__.merge is not None:
                obj_merge, obj_conf_merge = self.resolve_with_custom_merge(
                    dtype, oid,
                    self.make_temp_obj(start, dtype, oid),  # original
                    self.make_temp_obj(
                        start, dtype, oid, with_change=new_obj_change),  # new
                    self.make_temp_obj(
                        start, dtype, oid,
                        with_change=conf_obj_change),  # conflicting
                    new_obj_change, conf_obj_change)
            else:
                # LWW strategy
                obj_merge = self.dim_diff(new_obj_change, conf_obj_change)
                obj_conf_merge = self.dim_not_present(
                    conf_obj_change, new_obj_change)

        elif event_new is Event.Modification and event_conf is Event.Delete:
            # resolve between an app modifyinbg it,
            # and another app deleting the object.
            if dtype.__r_meta__.merge is not None:
                obj_merge, obj_conf_merge = self.resolve_with_custom_merge(
                    dtype, oid,
                    self.make_temp_obj(start, dtype, oid),  # original
                    self.make_temp_obj(
                        start, dtype, oid, with_change=new_obj_change),  # new
                    None,  # conflicting
                    new_obj_change, conf_obj_change)
            else:
                # LWW strategy
                obj_merge = conf_obj_change
                obj_conf_merge = dict()

        elif event_new is Event.Delete and event_conf is Event.New:
            # This has to be an error again using the
            # logic explained in the above comments.
            raise RuntimeError(
                "Divergent deletion received when "
                "object was created in the main line.")
        elif event_new is Event.Delete and event_conf is Event.Modification:
            # resolve between an app modifyinbg it,
            # and another app deleting the object.
            if dtype.__r_meta__.merge is not None:
                obj_merge, obj_conf_merge = self.resolve_with_custom_merge(
                    dtype, oid,
                    self.make_temp_obj(start, dtype, oid),  # original
                    None,  # new
                    self.make_temp_obj(
                        start, dtype, oid,
                        with_change=conf_obj_change),  # conflicting
                    new_obj_change, conf_obj_change)
            else:
                # LWW strategy
                obj_merge = conf_obj_change
                obj_conf_merge = dict()
        elif event_new is Event.Delete and event_conf is Event.Delete:
            # Both apps are deleting it, just delete it.
            # and so do nothing as the changes are already there.
            pass
        return obj_merge, obj_conf_merge

    def resolve_with_custom_merge(
            self, dtype, oid, original, new, conflicting,
            new_obj_change, conf_obj_changes):
        obj = dtype.__r_meta__.merge(original, new, conflicting)  # conflicting
        dtpname = dtype.__r_meta__.name
        if obj:
            changes = {
                "dims": dtype.__r_table__.store_as_temp[oid], "types": dict()}
            changes["types"][dtpname] = (
                Event.Modification if original is not None else Event.New)
            
            del dtype.__r_table__.store_as_temp[oid]
            return (self.dim_diff(new_obj_change, changes),
                    self.dim_diff(conf_obj_changes, changes))
        else:
            # Object was deleted.
            return (
                {"types": {dtpname: Event.Delete}},
                {"types": {dtpname: Event.Delete}})

    def make_temp_obj(self, version, dtype, oid, with_change=dict()):
        obj = utils._container()
        obj.__class__ = dtype
        obj.__r_oid__ = oid
        obj.__r_temp__ = {
            dimname: (
                with_change["dims"][dimname]
                if "dims" in with_change and dimname in with_change["dims"] else
                self.read_dimension_at(version, dtype, oid, dimname))
            for dimname in dtype.__r_meta__.dimmap}
        
        dtype.__r_table__.store_as_temp[oid] = dict()
        return obj

    def read_dimension_at(self, version, dtype, oid, dimname):
        dtpname = dtype.__r_meta__.name
        for change in self.version_graph[version::-1]:
            if dtpname in change and oid in change[dtpname]:
                if ("dims" in change[dtpname][oid]
                        and dimname in change[dtpname][oid]["dims"]):
                    return change[dtpname][oid]["dims"][dimname]
                if ("types" in change[dtpname][oid]
                        and dtpname in change[dtpname][oid]["types"]
                        and change[dtpname][oid]["types"][dtpname] == Event.Delete):
                    # Object has been deleted before this version,
                    # and has not been added.
                    # Do not return a value.
                    break

    def dim_diff(self, original, new):
        # return dims that are in new but not in/different in the original.
        change = {"dims": dict(), "types": dict()}
        if not (original and "dims" in original):
            return new
        for dim in new["dims"]:
            if (dim not in original["dims"]
                    or original["dims"][dim] != new["dims"][dim]):
                # The dim is not in original or the dim is there,
                # but the values are different.
                # copy it.
                change["dims"][dim] = new["dims"][dim]
        change["types"].update(original["types"])
        change["types"].update(new["types"])
        return change

    def dim_not_present(self, original, new):
        # return dims that are in new but not in in the original.
        change = {"dims": dict(), "types": dict()}
        if not (original and "dims" in original):
            return new
        for dim in new["dims"]:
            if dim not in original["dims"]:
                # The dim is not in original or the dim is there,
                # but the values are different.
                # copy it.
                change["dims"][dim] = new["dims"][dim]
        change["types"].update(original["types"])
        change["types"].update(new["types"])
        return change


    def maintain(self, appname, end_v):
        # reset the state markers.
        self.state_to_app.setdefault(end_v, set()).add(appname)
        if appname in self.app_to_state:
            if self.app_to_state[appname] == end_v:
                self.logger.debug("Don't need to maintain.")
                return
            old_v = self.app_to_state[appname]
            self.state_to_app[old_v].remove(appname)
            if not self.state_to_app[old_v]:
                del self.state_to_app[old_v]
        self.app_to_state[appname] = end_v
        self.logger.debug(
            "Maintaining with {0}, {1}".format(
                self.app_to_state, self.state_to_app))
        # Clean up states.

        self.version_graph.maintain(self.state_to_app, utils.merge_state_delta)
