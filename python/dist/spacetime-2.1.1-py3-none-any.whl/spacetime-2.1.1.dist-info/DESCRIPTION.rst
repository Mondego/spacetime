This is the implementation of spacetime and relational types in Python. See https://github.com/Mondego/spacetime


