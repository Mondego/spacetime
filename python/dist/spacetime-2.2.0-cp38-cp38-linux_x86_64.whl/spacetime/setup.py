from distutils.core import setup, Extension
import os

repository = Extension('spacetime.repository',
                    #library_dirs = ['.'],
                    include_dirs = ['../core/include', '../core/libs', '../core/libs/asio/include'],
                    sources = ['spacetime/py_repository.cpp', 'spacetime/pyobj_guard.cpp'],
                    extra_objects=['../build/libdataframe_core.a'],
                    extra_compile_args=['-g', '--std=c++17'],
                    language="c++")

setup (name = 'Spacetime_Core',
       version = '1.0',
       description = 'Spacetime core c++ library.',
       ext_modules = [repository])
